This is a redesign of the Matrix Glitch Chip for the Xbox 360.

*DISCLAIMER* - this product is no where ready to be ordered and tested, however I put it out to test the 
waters, and hopefully somebody might take this work and put their own twist on it. This is not the final
revision as it needs a lot of work, but I plan to put the time in to make this better.

Looking at the chip (with points facing down) this is the order of the points:

Left= VCC (3v3)
Right= GND

for points on the bottom from left to right:

RST - POST - CLK - DB2G3 - PLL


*NOTE* somewhere along the line, RST got mixed in with ground so it is now a part of the GND plain (which needs fixing)